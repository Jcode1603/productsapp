import datetime
from statistics import mode
from unicodedata import category
from django.db import models
from django.urls import reverse
from django.utils.text import slugify

# Create your models here.
class ProductsModel(models.Model):
    title = models.CharField(max_length=30, blank=True)
    description = models.CharField(max_length=255, blank=True)
    category = models.CharField(max_length=255, blank=True)
    price = models.FloatField(blank=True, default=0.0)
    slug = models.SlugField(default='', blank=True, max_length=255)
    quantity_available = models.IntegerField(blank=True, default=0.0)
    date_created = models.DateField(default=datetime.date.today(), max_length=40)
    date_updated = models.DateField(blank=True, max_length=30)

    def __str__(self):
        return self.title

    def save(self, *args, **kwargs):
        self.slug = slugify(self.title)
        self.date_updated = datetime.date.today()
    
    def get_absolute_url(self):
        return reverse('productsapp:create', args=[str(self.slug)])
