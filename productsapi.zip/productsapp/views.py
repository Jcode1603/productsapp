from itertools import product
from django.shortcuts import render, get_object_or_404, redirect
from .forms import Create_Product, Delete_Product
from .models import ProductsModel

# Create your views here.

def home(request):
    products = ProductsModel.objects.all()
    return render(request, 'home.html', {'products': products})

def create_products(request):
    if request.method == 'POST':
        form = Create_Product(request.POST)
        print(form)
        if form.is_valid():
            post = form.save(commit=False)
            post.save()
            return redirect('home')
    else:
        form = Create_Product()

    return render(request, 'productsapp/create.html', {'section': 'field_create',
                                                      'form': form})

def delete_products(request, pk=None):
    product = get_object_or_404(ProductsModel, pk=pk)
    if request.method == 'POST':
        form = Delete_Product(request.POST, instance=product)
        if form.is_valid:
            product.delete()
            return redirect('home')
    else:
        form = Delete_Product(request.POST, instance=product)

    return render(request, 'productsapp/delete.html', {'section': 'delete_field',
                                                      'form': form,
                                                      'field': product})

def buy_products(request, pk=None):
    product = get_object_or_404(ProductsModel, pk=pk)
    if request.method == 'POST':
        product.quantity_available -= 1
        return redirect('home')
    return redirect('home')
