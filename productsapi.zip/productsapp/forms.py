from django.forms import ModelForm
from .models import ProductsModel


class Create_Product(ModelForm):
    class Meta:
        model = ProductsModel
        fields = ['title', 'description', 'category', 'price', 'quantity_available', 'date_created', 'date_updated']

class Delete_Product(ModelForm):
    class Meta:
        model = ProductsModel
        fields = []