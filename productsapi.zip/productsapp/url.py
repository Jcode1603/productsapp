from django.urls import path
from . import views

app_name = 'productsapp'

urlpatterns = [path('create/', views.create_products, name='create'),
               path('delete/<int:pk>/', views.delete_products, name='delete')]